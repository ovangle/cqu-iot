from __future__ import annotations

from abc import abstractmethod
from typing import AsyncIterable, TypeVar
from asyncio import Future
import asyncio
import dataclasses
import json
from typing import Callable
from paho.mqtt.client import MQTTv311, CallbackAPIVersion
from asyncio_mqtt import Client as MQTTClient

from mech_arm_mqtt.schema.actions import BeginSession, MechArmAction, MoveAction
from mech_arm_mqtt.schema.events import (
    Busy,
    BadAction,
    InvalidActionError,
    MechArmBusyError,
    MechArmEvent,
    SessionCreated,
    SessionExit,
    SessionReady,
    SessionTimeout,
    action_from_json_object,
    event_to_json_object,
)
from mech_arm_mqtt.schema.protocol import MechArmClient


class MyCobotRemoteClient(MQTTClient, MechArmClient['MyCobotRemoteSession']):
    def __init__(
        self,
        client_id: str,
    ):
        super().__init__(
            CallbackAPIVersion.VERSION2,
            client_id=client_id,
            protocol=MQTTv311,
        )
        self._all_event_handlers = {}

    TEvent = TypeVar("TEvent", bound=MechArmEvent, contravariant=True)
    @property
    def mecharm_broadcast_topic(self) -> str:
        raise NotImplementedError

    async def message_broadcast_events(self) -> AsyncIterable[MechArmEvent]:
        async with self.messages() as messages:
            async for message in messages:
                try:
                    message_object = json.loads(message.payload)
                    event = event_to_json_object(message_object)
                except ValueError:
                    raise e
                if event.mecharm_client_id != self.mecharm_client_id:
                    continue
                yield event
                

    @property
    def mecharm_action_topic(self) -> str:
        raise NotImplementedError

    def dispatch_action(self, action: MechArmAction):
        action_dict = dataclasses.asdict(action)
        self.publish(self.mecharm_broadcast_topic, json.dumps(action_dict))

    def begin_session(
        self, arm_application_id: str
    ) -> Future[MyCobotRemoteSession]:
        created_session: Future[MyCobotRemoteSession] = asyncio.Future()

        begin_session_action = BeginSession(mecharm_application_id=arm_application_id)

        def on_session_created(evt: SessionCreated):
            if evt.action_id == begin_session_action.action_id:
                session = MyCobotRemoteSession(
                    self, evt.mech_arm_application_id, evt.session_id
                )
                session.init()
                created_session.set_result(session)
                unsubscribe_all()

        unsubscribe_success_handler = self.add_event_handler(
            "session_created", on_session_created
        )

        def on_invalid_action(evt: BadAction):
            if evt.action_id == begin_session_action.action_id:
                created_session.set_exception(InvalidActionError(evt))
                unsubscribe_all()

        usubscribe_invalid_action_error_handler = self.add_event_handler(
            "invalid_action", on_invalid_action
        )

        def on_mecharm_busy(evt: ArmBusy):
            if evt.action_id == begin_session_action.action_id:
                created_session.set_exception(MechArmBusyError(evt))
                unsubscribe_all()

        unsubscribe_busy_error_handler = self.add_event_handler("busy", on_mecharm_busy)

        def unsubscribe_all():
            unsubscribe_success_handler()
            usubscribe_invalid_action_error_handler()
            unsubscribe_busy_error_handler()

        self.dispatch_action(begin_session_action)

        return created_session


class MyCobotRemoteSession:
    def __init__(
        self,
        client: MyCobotRemoteClient,
        arm_application_id: str,
        session_id: int,
    ):
        self.client = client
        self.arm_application_id = arm_application_id
        self.session_id = session_id
        self.is_closed = False

    def move_arm(self, action: MoveAction) -> asyncio.Future[MoveComplete]:
        completed_action:Future[SessionReady] = asyncio.Future()

        def on_move_complete(evt: MoveComplete):

        self.client.dispatch_action(action)

        def unsubscribe_all():


        return completed_action

    def move_arm(self, action: MoveAction):
        self.dispatch_action(action)

    def add_on_ready(self, session_ready: SessionReady) -> Callable[[], None]:
        return self.client.add_event_handler("session_ready", session_ready)

    _unsubscribe_on_timeout: Callable[[], None] | None

    def on_timeout(self, session_timeout: SessionTimeout):
        """
        A timeout event happens when an action declares that
        the sesion should wait for the same controller to
        execute another action, but the controller has issued
        no further requests
        """
        if session_timeout.session_id == self.session_id:
            print(f"session timed out {session_timeout}")
            self.destroy()

    _unsubscribe_on_exit: Callable[[], None] | None

    def on_exit(self, session_exit: SessionExit):
        if session_exit.session_id == self.session_id:
            print(f"session exited successfully {sesesion_exit}")
            self.destroy()

    def init(self):
        self._unsubscribe_on_timeout = self.client.add_event_handler(
            "session_timeout", lambda session_timeout: self.on_timeout(session_timeout)
        )
        self._unsubscribe_on_exit = self.client.client.add_event_handler(
            "session_exit", lambda session_exit: self.on_exit(session_exit)
        )

    def destroy(self):
        if self._unsubscribe_on_timeout:
            self._unsubscribe_on_timeout()
        if self._unsubscribe_on_exit:
            self._unsubscribe_on_exit()
